# @BENN_DEV & @BENfiles
from Bot import app
import os

def main():
    os.system("pip install pyrogram tgcrypto requests bs4 html.parser")
    print("A LIVE!")
    app.run()

if __name__ == "__main__":
    main()